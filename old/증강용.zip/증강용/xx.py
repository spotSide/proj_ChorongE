from PIL import Image, ImageOps
import os
import argparse
import random

def augment_images(input_folder, output_folder, num_variations):
    """
    지정된 폴더의 이미지들을 변형하여 새로운 이미지를 생성합니다.

    Args:
        input_folder: 원본 이미지가 있는 폴더 경로.
        output_folder: 변형된 이미지를 저장할 폴더 경로.
        num_variations: 각 이미지 당 생성할 변형 이미지 수.
    """

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            try:
                img_path = os.path.join(input_folder, filename)
                img = Image.open(img_path)

                for i in range(num_variations):
                    augmented_img = img.copy()

                    # Random transformations
                    if random.random() > 0.5:  # 50% 확률로 좌우 반전
                        augmented_img = ImageOps.mirror(augmented_img)
                    if random.random() > 0.5:  # 50% 확률로 상하 반전
                        augmented_img = ImageOps.flip(augmented_img)

                    angle = random.randint(-45, 45) # -45 ~ 45 사이의 랜덤 회전
                    augmented_img = augmented_img.rotate(angle, expand=True)

                    # Brightness
                    brightness_factor = random.uniform(0.8, 1.2) # 밝기 조절 (0.8 ~ 1.2 사이)
                    augmented_img = ImageEnhance.Brightness(augmented_img).enhance(brightness_factor)
                    
                    # Contrast
                    contrast_factor = random.uniform(0.8, 1.2) # 콘트라스트 조절 (0.8 ~ 1.2 사이)
                    augmented_img = ImageEnhance.Contrast(augmented_img).enhance(contrast_factor)
                    
                    # Sharpness
                    sharpness_factor = random.uniform(0.8, 1.2) # 선명도 조절 (0.8 ~ 1.2 사이)
                    augmented_img = ImageEnhance.Sharpness(augmented_img).enhance(sharpness_factor)

                    output_filename = f"{os.path.splitext(filename)[0]}_aug_{i}{os.path.splitext(filename)[1]}"
                    output_path = os.path.join(output_folder, output_filename)
                    augmented_img.save(output_path)

                print(f"Processed: {filename}")

            except Exception as e:
                print(f"Error processing {filename}: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Augment images in a folder.")
    parser.add_argument("input_folder", help="Input folder containing images.")
    parser.add_argument("output_folder", help="Output folder to save augmented images.")
    parser.add_argument("-n", "--num_variations", type=int, default=5,
                        help="Number of variations per image.")

    args = parser.parse_args()

    augment_images(args.input_folder, args.output_folder, args.num_variations)